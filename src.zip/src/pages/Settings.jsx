import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Settings as SettingsIcon, User, Trash2, Moon, Sun, Loader2, LogOut, Shield, Brain } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function Settings() {
  const [deleting, setDeleting] = useState(false);

  const { data: user, isLoading } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const handleDeleteAccount = async () => {
    setDeleting(true);
    try {
      await base44.auth.deleteAccount();
      toast.success('Account deleted successfully');
      window.location.href = '/';
    } catch (error) {
      toast.error('Failed to delete account');
      setDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600 dark:text-purple-400" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <Card className="max-w-md w-full dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="pt-6 text-center space-y-4">
            <p className="text-gray-600 dark:text-gray-400">Sign in to access your settings</p>
            <Button onClick={() => base44.auth.redirectToLogin(createPageUrl('Settings'))} className="bg-purple-600 hover:bg-purple-700">
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mb-2">Settings</h1>
          <p className="text-gray-600 dark:text-gray-400">Manage your account and preferences</p>
        </div>

        {/* Account Information */}
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-gray-100">
              <User className="h-5 w-5" />
              Account Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-600 dark:text-gray-400">Email</span>
              <span className="font-medium text-gray-900 dark:text-gray-100">{user.email}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-600 dark:text-gray-400">Full Name</span>
              <span className="font-medium text-gray-900 dark:text-gray-100">{user.full_name || 'Not set'}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-600 dark:text-gray-400">Role</span>
              <span className="font-medium text-gray-900 dark:text-gray-100 capitalize">{user.role}</span>
            </div>
          </CardContent>
        </Card>

        {/* Appearance */}
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-gray-100">
              <Moon className="h-5 w-5" />
              Appearance
            </CardTitle>
            <CardDescription className="dark:text-gray-400">
              Theme automatically follows your system preferences
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="flex items-center gap-3">
                <Sun className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                <span className="text-gray-900 dark:text-gray-100">System Theme</span>
              </div>
              <span className="text-sm text-gray-600 dark:text-gray-400">Auto</span>
            </div>
          </CardContent>
        </Card>

        {/* Privacy Policy Link */}
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="pt-4 pb-4">
            <a href={createPageUrl('AboutAICoach')} className="flex items-center justify-between py-2 hover:text-purple-600 transition-colors">
              <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                <Brain className="h-5 w-5" />
                <span className="font-medium">About AI Coach</span>
              </div>
              <span className="text-gray-400">→</span>
            </a>
            <a href={createPageUrl('PrivacyPolicy')} className="flex items-center justify-between py-2 hover:text-purple-600 transition-colors">
              <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                <Shield className="h-5 w-5" />
                <span className="font-medium">Privacy Policy & Terms</span>
              </div>
              <span className="text-gray-400">→</span>
            </a>
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                <LogOut className="h-5 w-5" />
                <span className="font-medium">Sign Out</span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => base44.auth.logout(createPageUrl('Auth'))} className="text-red-500 hover:text-red-700 hover:bg-red-50">
                Sign Out
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-red-200 dark:border-red-900 dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
              <Trash2 className="h-5 w-5" />
              Danger Zone
            </CardTitle>
            <CardDescription className="dark:text-gray-400">
              Irreversible actions that affect your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  variant="destructive" 
                  className="w-full min-h-[44px] select-none"
                  disabled={deleting}
                >
                  {deleting ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4 mr-2" />
                  )}
                  Delete Account
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="dark:bg-gray-800 dark:border-gray-700">
                <AlertDialogHeader>
                  <AlertDialogTitle className="dark:text-gray-100">Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription className="dark:text-gray-400">
                    This action cannot be undone. This will permanently delete your account
                    and remove all your data from our servers, including:
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      <li>All workout sessions and progress data</li>
                      <li>Personalized workout plans</li>
                      <li>Body measurements and nutrition logs</li>
                      <li>Exercise logs and personal records</li>
                    </ul>
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="min-h-[44px] select-none dark:bg-gray-700 dark:text-gray-100 dark:hover:bg-gray-600">
                    Cancel
                  </AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDeleteAccount}
                    className="bg-red-600 hover:bg-red-700 min-h-[44px] select-none"
                    disabled={deleting}
                  >
                    {deleting ? 'Deleting...' : 'Delete Account'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
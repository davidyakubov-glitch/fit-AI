/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AboutAICoach from './pages/AboutAICoach';
import Auth from './pages/Auth';
import Community from './pages/Community';
import Nutrition from './pages/Nutrition';
import PrivacyPolicy from './pages/PrivacyPolicy';
import Progress from './pages/Progress';
import Settings from './pages/Settings';
import Workout from './pages/Workout';
import WorkoutPlan from './pages/WorkoutPlan';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AboutAICoach": AboutAICoach,
    "Auth": Auth,
    "Community": Community,
    "Nutrition": Nutrition,
    "PrivacyPolicy": PrivacyPolicy,
    "Progress": Progress,
    "Settings": Settings,
    "Workout": Workout,
    "WorkoutPlan": WorkoutPlan,
}

export const pagesConfig = {
    mainPage: "Workout",
    Pages: PAGES,
    Layout: __Layout,
};